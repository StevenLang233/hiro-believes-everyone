param([ValidateSet('Install','Uninstall')][string]$Action)
$ErrorActionPreference='Stop'
try {
 $game = [System.IO.Directory]::GetParent($PSScriptRoot).FullName
 if (!(Test-Path -LiteralPath (Join-Path $game 'manosaba.exe') -PathType Leaf)) { throw 'Place this whole folder beside manosaba.exe.' }
 if (Get-Process -Name manosaba -ErrorAction SilentlyContinue) { throw 'Close the game first.' }
 if ($Action -eq 'Install') {
  foreach ($p in @('BepInEx\core\BepInEx.Unity.IL2CPP.dll','BepInEx\plugins\ManosabaLoader.dll')) { if (!(Test-Path -LiteralPath (Join-Path $game $p) -PathType Leaf)) { throw "Dependency missing: $p. See README." } }
  foreach ($p in @('BepInEx\plugins\ManosabaTrial12Fix.dll','ManosabaMod\HiroBelievesEveryone\info.json')) {
   $src=Join-Path $PSScriptRoot $p; $dst=Join-Path $game $p
   if (!(Test-Path -LiteralPath $src -PathType Leaf)) { throw "Package file missing: $src" }
   if ((Test-Path -LiteralPath $dst) -and ((Get-FileHash -LiteralPath $src).Hash -ne (Get-FileHash -LiteralPath $dst).Hash)) { throw "Different file exists; refusing to overwrite: $dst" }
  }
  & (Join-Path $PSScriptRoot 'install.ps1') -GameRoot $game
 } else { & (Join-Path $PSScriptRoot 'uninstall.ps1') -GameRoot $game }
 Write-Host 'Finished.'
} catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
